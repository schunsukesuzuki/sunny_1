import json

def load_input():
    with open('/home/user/input.json', 'r') as f:
        return json.load(f)

def save_output(assignments, unassigned_case_ids):
    output = {
        "assignments": assignments,
        "unassigned_case_ids": unassigned_case_ids
    }
    with open('/home/user/output.json', 'w') as f:
        json.dump(output, f, indent=2)

def is_skill_match(case, reviewer):
    return case["required_skill"] in reviewer["skills"]

def can_assign(case, reviewer, day):
    # Check if reviewer has capacity for this day
    if day >= len(reviewer["daily_capacity_hours"]):
        return False
    
    capacity = reviewer["daily_capacity_hours"][day]
    
    # Check if case duration fits within capacity
    if case["duration_hours"] > capacity:
        return False
    
    return True

def assign_case_to_reviewer(case, reviewer, day):
    hours = case["duration_hours"]
    assignment = {
        "case_id": case["case_id"],
        "reviewer_id": reviewer["reviewer_id"],
        "day": day,
        "hours": hours
    }
    return assignment

def find_best_assignment(case, reviewers, days):
    best_assignment = None
    best_deadline_risk = float('inf')
    
    for reviewer in reviewers:
        if not is_skill_match(case, reviewer):
            continue
        
        # Try to assign to earliest possible day
        for day in range(min(days, len(reviewer["daily_capacity_hours"]))):
            if can_assign(case, reviewer, day):
                deadline_risk = max(0, day - case["deadline_day"])
                
                if deadline_risk < best_deadline_risk:
                    best_deadline_risk = deadline_risk
                    best_assignment = assign_case_to_reviewer(case, reviewer, day)
    
    return best_assignment

def main():
    data = load_input()
    days = data["days"]
    cases = data["cases"]
    reviewers = data["reviewers"]
    
    assignments = []
    unassigned_case_ids = []
    
    # Sort cases by deadline day (earliest first) to prioritize deadline risk
    sorted_cases = sorted(cases, key=lambda x: x["deadline_day"])
    
    for case in sorted_cases:
        assignment = find_best_assignment(case, reviewers, days)
        
        if assignment:
            assignments.append(assignment)
        else:
            unassigned_case_ids.append(case["case_id"])
    
    save_output(assignments, unassigned_case_ids)

if __name__ == "__main__":
    main()