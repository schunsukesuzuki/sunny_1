# Claims Operations Planner — v0.31 Human-in-the-loop Technical Proposal + Independent Evaluation Audit Package

- Export: `4b6c9177-1a24-4ea1-89b3-943d45e3c2a4`
- Original experiment: `ed5aee84-5068-49ff-9548-0736a86357c4`
- Export completeness: **PARTIAL**
- Files included: **285**
- All methods run on synthetic customer/case fixtures, not real customer data.
- GO, if any, means *Customer Discovery only*. Production is never authorized.
- Public-evidence mode pauses at step 00b for explicit human review; step 05 also requires human approval.
- Public source materials are screened for topic relevance; mismatched evidence is blocked. Human-selected thresholds run on fixed synthetic claims cases. No arbitrary customer requirements are executable.
- Raw source snapshots and original document SHA256 are included in the workflow folder; additional policy/stress and configured-KPI results are stored separately.
- `manifest.json` lists every included file with raw-bytes SHA256, omitted categories, and failures.

## Execution stages

- **00_evidence_grounded_requirements**: COMPLETED_WITH_FINDINGS — 6 public excerpts; source hashes checked; semantic support unverified
- **00b_evidence_review**: COMPLETED — Human selected public source pointers and a hypothetical requirement; NOT customer-approved
- **00c_grounded_test_contract**: COMPLETED — Human-configured bounded KPI evaluator; pinned synthetic test fixture
- **01_input**: COMPLETED — Evidence-reviewed hypothesis inserted into 01 brief; fixed synthetic R0 contract unchanged
- **02_service_design**: COMPLETED — Qwen draft; not customer-approved
- **03_r0_e2b**: COMPLETED — PASS
- **04_independent_diagnoses**: COMPLETED_WITH_FINDINGS — ODA rubric: HOLD
- **05_human_approval**: COMPLETED — explicit human decision; original ODA HOLD remains preserved
- **06_r1_generation_and_evaluation**: COMPLETED_WITH_FINDINGS — R1 mode: compare; selected: skill_deadline_scarcity; KPI/HOLDOUT: True
- **07_audit_index**: COMPLETED — saved evidence index; archived records retrievable by 07
- **08_diagnostic_benchmark**: INCOMPLETE — execution: INCOMPLETE_TIMEOUT; diagnostic quality: HOLD_HUMAN_ADJUDICATION; raw scores only
- **08b_policy_and_stress**: COMPLETED_WITH_FINDINGS — R1 behavioral + stress evaluation
- **08c_grounded_kpi_verification**: COMPLETED_WITH_FINDINGS — Typed assignment gate: NOT_APPLICABLE_TO_NOTIFICATION
- **08d_notification_prototype**: COMPLETED_WITH_FINDINGS — SUPPORTED_SYNTHETIC_PROTOTYPE; deterministic example only, not R1
- **08e_requirement_trace**: COMPLETED_WITH_FINDINGS — SYNTHETIC_PROTOTYPE_ONLY; customer not approved
- **08f_blind_optimality**: COMPLETED_WITH_FINDINGS — Post-selection blind synthetic benchmark; solver status and gaps saved
- **08g_boundary_assurance**: COMPLETED_WITH_FINDINGS — Boundary checks: PASS_CONTROLLED; simulated scenarios: PASS
- **09_business_delivery_assessment**: SKIPPED — 08 diagnostic incomplete; 09 deferred until replay

## Assessment

- Assessment not produced; see stage failure in manifest.

## Reading order

10P. `workflows/<id>/10p_advisory_vNNNN.json` and `10p_review_vNNNN.json` — post-run AI proposal drafts and human feedback, NOT customer approval
0. `workflows/<id>/00_evidence_grounded_requirements.json`, `00_source_manifest.json`, `00_index_metadata.json`, `00_rag_report.md` — retrieved public evidence; no real-world approval
0b. `workflows/<id>/00b_human_evidence_review.json` — human-selected evidence; check domain alignment and reviewer judgment
0c. `workflows/<id>/00c_grounded_test_contract.json` and `00c_technical_spec.md` — human-configured bounded KPI thresholds
8c. `workflows/<id>/08c_grounded_kpi_verification.json` — bounded deterministic evaluation; SYNTHETIC ONLY
8e. `workflows/<id>/08e_feature_acceptance.json` — feature-specific typed acceptance; no cross-feature substitution
8f. `workflows/<id>/08f_selection_gap_analysis.json` — post-selection blind exact comparison; cannot alter DEV decision
6b. `experiments/<id>/dev_robustness_preselection.json` — pre-HOLDOUT DEV and four stress fixtures, leave-one-out sensitivity, no 08f input
8a. `benchmarks/<id>/diagnostic_axes.json`, `workflows/<id>/08_diagnostic_axes.json` — independent RAW diagnostic axes (fixed initial/latest, blind), no assisted answer substitution
8s. `workflows/<id>/08_latest_state_index.json` — current benchmark.json is authoritative; earlier retry snapshots are historical
8g. `workflows/<id>/08g_dogwood_negative_audit.json` — synthetic Rust deny-path and ledger mismatch evidence
1. `workflows/<id>/01_input.json` and `02_service_design.json` — input and generated service design (v0.15 full batch)
2. `assessments/<id>/report.md` — business/delivery decision and evidence register
3. `policy_validations/<id>/report.md` — semantic contract and stress failures
4. `benchmarks/<id>/report.md` — diagnostic comparison (single-case PASS is NOT model reliability)
5. `experiments/<id>/report.md` — R0/R1 KPI and source attempts
5b. `experiments/<id>/skill_manifest.json`, `skill_component_*.py`, `skill_*.py` — pinned Domain Skill, code hashes, E2B comparisons (if opted in)
5c. `workflows/<id>/08f_blind_optimality.json` and `08f_exact_*.json` — post-selection randomized independent exact-solver comparison (solver status required)
5d. `workflows/<id>/08g_boundary_assurance.json`, `.md`, `08g_provenance_dag.json`, `09_final_provenance_dag.json` — small EAIR-inspired cross-stage audit
5e. `workflows/<id>/05_authorization_ledger.json`, `approvals/<id>/revocation.json` (if revoked) — durable SQLite journal receipts; hashes do not prove human identity
5f. `workflows/<id>/08_diagnostic_reliability_gate.json`, `benchmarks/<id>/diagnostic_reliability_gate.json` — raw diagnostic generalization gate; HOLD requires human adjudication
5g. `workflows/<id>/05_dogwood_authorization.json`, `boundary_05_to_06_dogwood.json`, `05_dogwood_policy.dw`, `05_dogwood_schema.cedarschema` — native Dogwood temporal verdict (or explicit NOT_ENFORCED in tests) and its exact policy/schema
6. `runs/`, `proposals/`, `approvals/` — lineage, data, LLM diagnoses, approval

## Known limitations

- Skill algorithms are reviewed code, not generated by the LLM; a Skill win is not LLM code-generation success.
- Bounded-beam optimization is NOT an exact solver. The v0.21 independent exact comparison is limited to small randomized cases and is certified only when status=OPTIMAL.
- Behavioral probes are not mathematical proof of the full specification.
- No high-load result can be generalized to production distributions.
- Unassigned claims are counted as missed deadlines; never ignore them when comparing methods.
- Synthetic evidence IDs are internal pointers, not public citations or validation.
- Dataset download and indexing must actually succeed in public mode; never interpret missing data as COMPLETED.
- Public banking materials do not support insurance claim workflows; the compatibility gate blocks such handoffs.
- FCA/FOS material supports problem context but does not establish a scheduling mechanism or a German customer request.
- Source manifest/file hashes establish local integrity only, not semantic truth or representative sampling.
- Public evidence excerpts remain unverified as supporting customer requirements; RAG is never automatic approval.
- AI model diagnostics, human approval, and KPI PASS have separate scopes.
- Missing experiment.json after evaluation_started.json is an upstream failure; 08b/08f/09 must not claim independent verification.
- Boundary assurance is limited to local IDs, approval records, state, and declared dependencies; not a formal verification or authenticated security system.
- A durable SQLite approval/revocation journal now backs each decision, but Dogwood still replays events in an ephemeral engine: no continuous Dogwood history, no verified identity provider, no production authorization.

**Partial/incomplete output:** See `manifest.json` for missing or skipped artifacts.
