# Claims Operations Planner — v0.18 Evidence-to-Evaluation Audit Package

- Export: `a056d96d-35c8-4399-bc49-8d9050cba8f1`
- Original experiment: `115c0ce9-ab09-4027-b981-2599a8490975`
- Export completeness: **COMPLETE**
- Files included: **110**
- All methods run on synthetic customer/case fixtures, not real customer data.
- GO, if any, means *Customer Discovery only*. Production is never authorized.
- Public-evidence mode pauses at step 00b for explicit human review; step 05 also requires human approval.
- Public source materials are screened for topic relevance; mismatched evidence is blocked. Human-selected thresholds run on fixed synthetic claims cases. No arbitrary customer requirements are executable.
- Raw source snapshots and original document SHA256 are included in the workflow folder; additional policy/stress and configured-KPI results are stored separately.
- `manifest.json` lists every included file with raw-bytes SHA256, omitted categories, and failures.

## Execution stages

- **00_evidence_grounded_requirements**: COMPLETED_WITH_FINDINGS — 6 public excerpts; source hashes checked; semantic support unverified
- **00b_evidence_review**: COMPLETED — Human selected public source pointers and a hypothetical requirement; NOT customer-approved
- **00c_grounded_test_contract**: COMPLETED — Human-configured bounded KPI evaluator; pinned synthetic test fixture
- **01_input**: COMPLETED — Evidence-reviewed hypothesis inserted into 01 brief; fixed synthetic R0 contract unchanged
- **02_service_design**: COMPLETED — Qwen draft; not customer-approved
- **03_r0_e2b**: COMPLETED — PASS
- **04_independent_diagnoses**: COMPLETED_WITH_FINDINGS — ODA rubric: HOLD
- **05_human_approval**: COMPLETED — explicit human decision; original ODA HOLD remains preserved
- **06_r1_generation_and_evaluation**: COMPLETED_WITH_FINDINGS — KPI/HOLDOUT outcome: False
- **07_audit_index**: COMPLETED — saved evidence index; archived records retrievable by 07
- **08_diagnostic_benchmark**: COMPLETED_WITH_FINDINGS — summary counts are evidence, not model reliability
- **08b_policy_and_stress**: COMPLETED_WITH_FINDINGS — R1 behavioral + stress evaluation
- **08c_grounded_kpi_verification**: COMPLETED_WITH_FINDINGS — Human thresholds: HOLD (synthetic-only)
- **09_business_delivery_assessment**: COMPLETED_WITH_FINDINGS — Production remains NO-GO; public source is contextual

## Assessment

- Preliminary: **HOLD** (TECHNICAL_VALIDATION)
- Production: **NO_GO**
- R1 behavioral probes: **HOLD**
- Stress test vs heuristic: **REVIEW_REQUIRED**
- Diagnostic benchmark all PASS: **False**

## Reading order

0. `workflows/<id>/00_evidence_grounded_requirements.json`, `00_source_manifest.json`, `00_index_metadata.json`, `00_rag_report.md` — retrieved public evidence; no real-world approval
0b. `workflows/<id>/00b_human_evidence_review.json` — human-selected evidence; check domain alignment and reviewer judgment
0c. `workflows/<id>/00c_grounded_test_contract.json` and `00c_technical_spec.md` — human-configured bounded KPI thresholds
8c. `workflows/<id>/08c_grounded_kpi_verification.json` — bounded deterministic evaluation; SYNTHETIC ONLY
1. `workflows/<id>/01_input.json` and `02_service_design.json` — input and generated service design (v0.15 full batch)
2. `assessments/<id>/report.md` — business/delivery decision and evidence register
3. `policy_validations/<id>/report.md` — semantic contract and stress failures
4. `benchmarks/<id>/report.md` — diagnostic comparison (single-case PASS is NOT model reliability)
5. `experiments/<id>/report.md` — R0/R1 KPI and source attempts
6. `runs/`, `proposals/`, `approvals/` — lineage, data, LLM diagnoses, approval

## Known limitations

- Behavioral probes are not mathematical proof of the full specification.
- No high-load result can be generalized to production distributions.
- Unassigned claims are counted as missed deadlines; never ignore them when comparing methods.
- Synthetic evidence IDs are internal pointers, not public citations or validation.
- Dataset download and indexing must actually succeed in public mode; never interpret missing data as COMPLETED.
- Public banking materials do not support insurance claim workflows; the compatibility gate blocks such handoffs.
- FCA/FOS material supports problem context but does not establish a scheduling mechanism or a German customer request.
- Source manifest/file hashes establish local integrity only, not semantic truth or representative sampling.
- Public evidence excerpts remain unverified as supporting customer requirements; RAG is never automatic approval.
- AI model diagnostics, human approval, and KPI PASS have separate scopes.

