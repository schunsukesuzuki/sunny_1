import json

def load_input():
    with open('/home/user/input.json', 'r') as f:
        return json.load(f)

def save_output(assignments, unassigned_case_ids):
    output = {
        "assignments": assignments,
        "unassigned_case_ids": unassigned_case_ids
    }
    with open('/home/user/output.json', 'w') as f:
        json.dump(output, f, indent=2)

def is_skill_match(case, reviewer):
    return case["required_skill"] in reviewer["skills"]

def can_assign(case, reviewer, day):
    # Check if reviewer has capacity for this day
    if day >= len(reviewer["daily_capacity_hours"]):
        return False
    
    # Check if reviewer has enough capacity
    remaining_capacity = reviewer["daily_capacity_hours"][day]
    if remaining_capacity < case["duration_hours"]:
        return False
    
    return True

def assign_case(case, reviewer, day, assignments, unassigned_case_ids):
    # Update reviewer's capacity
    reviewer["daily_capacity_hours"][day] -= case["duration_hours"]
    
    # Add assignment
    assignment = {
        "case_id": case["case_id"],
        "reviewer_id": reviewer["reviewer_id"],
        "day": day,
        "hours": case["duration_hours"]
    }
    assignments.append(assignment)
    
    # Remove from unassigned
    if case["case_id"] in unassigned_case_ids:
        unassigned_case_ids.remove(case["case_id"])


def main():
    data = load_input()
    days = data["days"]
    cases = data["cases"]
    reviewers = data["reviewers"]
    
    # Initialize assignments and unassigned cases
    assignments = []
    unassigned_case_ids = [case["case_id"] for case in cases]
    
    # Sort cases by deadline (earliest first) - EDD heuristic
    cases.sort(key=lambda x: x["deadline_day"])
    
    # For each day, try to assign cases
    for day in range(days):
        # Create a copy of reviewers for this day to avoid modifying original data
        day_reviewers = []
        for reviewer in reviewers:
            day_reviewers.append({
                "reviewer_id": reviewer["reviewer_id"],
                "skills": reviewer["skills"],
                "daily_capacity_hours": reviewer["daily_capacity_hours"][:]
            })
        
        # Sort reviewers by skill scarcity (fewer reviewers with required skill)
        # This is a simplified approach - in reality, we'd want to prioritize
        # reviewers who are scarce for the specific skill needed
        
        # For each case that hasn't been assigned yet
        for case in cases:
            if case["case_id"] not in unassigned_case_ids:
                continue
            
            # Find a reviewer with matching skill and capacity
            best_reviewer = None
            min_capacity = float('inf')
            
            for reviewer in day_reviewers:
                if is_skill_match(case, reviewer) and can_assign(case, reviewer, day):
                    # Prefer reviewer with least remaining capacity (to avoid over-allocation)
                    remaining_capacity = reviewer["daily_capacity_hours"][day]
                    if remaining_capacity < min_capacity:
                        min_capacity = remaining_capacity
                        best_reviewer = reviewer
            
            if best_reviewer is not None:
                assign_case(case, best_reviewer, day, assignments, unassigned_case_ids)
    
    save_output(assignments, unassigned_case_ids)

if __name__ == "__main__":
    main()